package micronaut.gradle.app;

import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.HttpStatus;

@Controller("/hello")
public class HelloController {

    @Get("/")
    public HttpStatus index() {
        return HttpStatus.OK;
    }
    
    @Get("/message")
    public String message() {
        return "This is your first micronaut gradle app!!";
    }
    
    @Get("/employee")
    public Employee getEmployee() {
        return new Employee(1001,"Jhon");
    }
}