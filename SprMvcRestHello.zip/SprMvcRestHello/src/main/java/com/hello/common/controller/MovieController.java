package com.hello.common.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/movie")
public class MovieController {

	@RequestMapping(value="/{name}", method = RequestMethod.GET)
	public String getMovie(@PathVariable String name, ModelMap model) {

		model.addAttribute("movie", name);
		model.addAttribute("actor", "Actor");
		model.addAttribute("director", "Director");
		model.addAttribute("producer", "Spring Rest API");
		ModelMap subModel = new ModelMap();
		subModel.addAttribute("subModel", "Test of sub model");
		model.addAttribute("innerModel", subModel);
		return "list";
		
		// URL to execute
		// http://localhost:9080/SpringMVC/movie/ironMan
		// http://localhost:9080/SpringMVC/movie/SpiderMan4	
	}
}