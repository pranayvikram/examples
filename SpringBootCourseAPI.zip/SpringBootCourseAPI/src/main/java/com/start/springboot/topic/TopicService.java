package com.start.springboot.topic;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;


@Service
@Scope("prototype")
public class TopicService {


	@Autowired
	private TopicRepository topicRepository;
	 
	public List<Topic> getAllTopics() {
		
		List<Topic> topics = new ArrayList<>();
		for(Topic topic : topicRepository.findAll()) {
			topics.add(topic);
		}
		return topics;
	}
	
	
	public Topic getTopic(Integer id) {
		return topicRepository.findOne(id);
	}


	public void addTopic(Topic topic) {
		topicRepository.save(topic);
	}


	public void updateTopic(Integer id, Topic newTopic) {
		topicRepository.save(newTopic);
	}


	public void deleteTopic(Integer id) {
		topicRepository.delete(id);
		// topicss.removeIf(t -> t.getId().equals(id));
	}
	
	
}
