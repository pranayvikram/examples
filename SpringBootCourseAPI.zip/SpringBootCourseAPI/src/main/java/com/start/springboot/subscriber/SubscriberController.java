package com.start.springboot.subscriber;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.start.springboot.topic.TopicService;

@RestController
public class SubscriberController {

	
	@Autowired
	private TopicService topicService;
	
	@Autowired
	private SubscriberService subscriberService;
	
	
	@RequestMapping("topic/{id}/subscribers")
	public List<Subscriber> getAllSubscribers(@PathVariable Integer id) {
		 
		return subscriberService.getAllSubscriber(id);	
	}
	
	
	@RequestMapping("/topic/{topicId}/subscribers/{subscriberId}")
	public Subscriber getSubscriber(@PathVariable Integer subscriberId) {
		
		return subscriberService.getSubscriber(subscriberId);
	}
	
	
	@RequestMapping(value = {"/topic/{topicId}/subscribers"}, method = RequestMethod.POST)
	public void addSubscriber(@PathVariable Integer topicId, @RequestBody Subscriber subscriber) {
		
		subscriber.setTopic(topicService.getTopic(topicId));
		subscriber.setTopicId(topicId);
		this.subscriberService.addSubscriber(subscriber);
	}
	
	
	@RequestMapping(value = {"/topic/{topicId}/subscribers/{subscriberId}"}, method = RequestMethod.PUT)
	public void updateSubscriber(@PathVariable Integer topicId, @PathVariable Integer subscriberId, @RequestBody Subscriber subscriber) {
		subscriber.setTopic(topicService.getTopic(topicId));
		this.subscriberService.updateSubscriber(subscriber);
	}
	
	@RequestMapping(value = {"/topic/{topicId}/subscribers/{subscriberId"}, method = RequestMethod.DELETE)
	public void deleteSubscriber(@PathVariable Integer subscriberId) {
		this.subscriberService.deleteSubscriber(subscriberId);
	}
	
}
