package com.start.springboot.topic;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.start.springboot.subscriber.Subscriber;

@Entity
@Table(name="TOPIC")
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Topic implements Serializable {

	private static final long serialVersionUID = 5825809432833650650L;

	
	@Id @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TOPIC_SEQ_GEN")
	@SequenceGenerator(name = "TOPIC_SEQ_GEN", sequenceName = "TOPIC_SEQ", allocationSize = 1)
	@Column(name = "TOPICID", unique = true, updatable = false, nullable = false)
	private Integer topicId;
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="ACTIVE_IND")
	private Boolean active_ind;
	
	@Column(name="VALID")
	@Temporal(TemporalType.DATE)
	private Date valid;

	//@Cascade(CascadeType.ALL)
	/*@Fetch(FetchMode.JOIN)
    @BatchSize(size = 10)
	@JoinTable(name = "TOPIC", joinColumns = @JoinColumn(name = "SUBSCRIBERID"),
    		            inverseJoinColumns = @JoinColumn(name = "TOPICID"))*/
	
	@OneToMany(fetch=FetchType.LAZY, cascade = CascadeType.ALL, mappedBy="topicId")
	private List<Subscriber> subscriber;
		
	public Topic() {
	
	}
	
	public Topic(Integer topicId, String name, String description, Boolean active_ind, Date valid) {
		super();
		this.topicId = topicId;
		this.name = name;
		this.description = description;
		this.active_ind = active_ind;
		this.valid = valid;
	}
	
	public Integer getTopicId() {
		return topicId;
	}
	
	public void setTopicId(Integer topicId) {
		this.topicId = topicId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public Boolean getActive_ind() {
		return active_ind;
	}

	public void setActive_ind(Boolean active_ind) {
		this.active_ind = active_ind;
	}

	public Date getValid() {
		return valid;
	}

	public void setValid(Date valid) {
		this.valid = valid;
	}

	public List<Subscriber> getSubscriber() {
		return subscriber;
	}

	public void setSubscriber(List<Subscriber> subscriber) {
		this.subscriber = subscriber;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((topicId == null) ? 0 : topicId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Topic other = (Topic) obj;
		if (topicId == null) {
			if (other.topicId != null)
				return false;
		} else if (!topicId.equals(other.topicId))
			return false;
		return true;
	}

}
