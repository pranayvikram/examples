package com.start.springboot.subscriber;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SubscriberRepository extends CrudRepository<Subscriber, Integer> {
	
	public List<Subscriber> findSubscribersByTopicId(Integer topicId);
	
}
