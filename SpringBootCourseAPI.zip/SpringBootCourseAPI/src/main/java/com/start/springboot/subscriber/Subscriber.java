package com.start.springboot.subscriber;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.start.springboot.topic.Topic;

@Entity
@Table(name="SUBSCRIBER")
public class Subscriber implements Serializable {

	private static final long serialVersionUID = -1581945294473884256L;
	
	@Id @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SUBSCRIBER_SEQ_GEN")
	@SequenceGenerator(name = "SUBSCRIBER_SEQ_GEN", sequenceName = "SUBSCRIBER_SEQ", allocationSize = 1)
	@Column(name = "SUBSCRIBERID", unique = true, updatable = false, nullable = false)
	private Integer subscriberId;

	@Column(name="TOPICID")
	private Integer topicId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name="ACTIVE_IND")
	private Boolean active_ind;
	
	@Column(name="VALID")
	@Temporal(TemporalType.DATE)
	private Date valid;
	
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TOPICID", insertable=false, updatable=false)
	private Topic topic;
	
	
	public Subscriber() {
	
	}
	
	public Subscriber(Integer subscriberId, Integer topicId, String name, String description, Boolean active_ind, Date valid) {
		super();
		this.subscriberId = subscriberId;
		this.topicId = topicId;
		this.name = name;
		this.description = description;
		this.active_ind = active_ind;
		this.valid = valid;
		this.topic = new Topic(topicId, "", "", true, new Date());
	}
	
	public Integer getSubscriberId() {
		return subscriberId;
	}
	
	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}
	
	public Integer getTopicId() {
		return topicId;
	}

	public void setTopicId(Integer topicId) {
		this.topicId = topicId;
	}
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
		
	public Topic getTopic() {
		return topic;
	}

	public void setTopic(Topic topic) {
		this.topic = topic;
	}
	
	public Boolean getActive_ind() {
		return active_ind;
	}

	public void setActive_ind(Boolean active_ind) {
		this.active_ind = active_ind;
	}

	public Date getValid() {
		return valid;
	}

	public void setValid(Date valid) {
		this.valid = valid;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((subscriberId == null) ? 0 : subscriberId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Subscriber other = (Subscriber) obj;
		if (subscriberId == null) {
			if (other.subscriberId != null)
				return false;
		} else if (!subscriberId.equals(other.subscriberId))
			return false;
		return true;
	}

}
