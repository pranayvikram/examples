package com.start.springboot.subscriber;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("prototype")
public class SubscriberService {


	@Autowired
	private SubscriberRepository subscriberRepository;
	
	
	public List<Subscriber> getAllSubscriber(Integer topicId) {
		
		List<Subscriber> subscribers = new ArrayList<>();
		for(Subscriber subscriber : subscriberRepository.findSubscribersByTopicId(topicId)) {
			subscribers.add(subscriber);
		}
		
		return subscribers;
	}
	
	
	public Subscriber getSubscriber(Integer id) {
		return subscriberRepository.findOne(id);
	}


	public void addSubscriber(Subscriber subscriber) {
		subscriberRepository.save(subscriber);
	}


	public void updateSubscriber(Subscriber newTopic) {
		subscriberRepository.save(newTopic);
	}


	public void deleteSubscriber(Integer id) {
		subscriberRepository.delete(id);
	}
	
	
}
