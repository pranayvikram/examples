

INSERT INTO TOPIC VALUES(1001, 'Java', 'Java Description', 'Y', SYSDATE);
INSERT INTO TOPIC VALUES(1002, 'Javascript', 'Javascript Description', 'Y', SYSDATE);
INSERT INTO TOPIC VALUES(1003, 'Spring', 'Spring Description', 'Y', SYSDATE);
INSERT INTO TOPIC VALUES(1004, 'Youtube', 'Youtube Description', 'Y', SYSDATE);
INSERT INTO TOPIC VALUES(1005, 'Book',	'Book Description', 'Y', SYSDATE);



INSERT INTO Subscriber VALUES(2001, 1001, 'Peter', 'Peter Description', 'Y', SYSDATE);
INSERT INTO Subscriber VALUES(2002, 1002, 'Sam', 'Sam Description', 'Y', SYSDATE);
INSERT INTO Subscriber VALUES(2003, 1003, 'Test', 'Test Description', 'Y', SYSDATE);
INSERT INTO Subscriber VALUES(2004, 1005, 'Jack', 'Jack Description', 'Y', SYSDATE);
