
DROP TABLE topic IF EXISTS;

CREATE TABLE topic (
 topicid NUMBER(5) NOT NULL,
 name VARCHAR2(20) NOT NULL,
 description VARCHAR2(50),
 active_ind VARCHAR2(1),
 valid DATE,
 PRIMARY KEY (topicId)
);

DROP TABLE subscriber IF EXISTS;

CREATE TABLE subscriber (
 subscriberid NUMBER(5) NOT NULL,
 topicid NUMBER(5) NOT NULL,
 name VARCHAR2(20) NOT NULL,
 description VARCHAR2(50),
 active_ind VARCHAR2(1),
 valid DATE,
 PRIMARY KEY (subscriberid),
 FOREIGN KEY (topicid) REFERENCES topic(topicid)
);


 CREATE SEQUENCE TOPIC_SEQ
 START WITH     1005
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 

 CREATE SEQUENCE SUBSCRIBER_SEQ
 START WITH     2005
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
 